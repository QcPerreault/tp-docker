const express = require('express');
const app = express();
const mongodb = require('mongodb');

const url = 'mongodb://192.168.0.109:27017';
//const config = require('./db');
const PORT = 4000;
const client = mongodb.MongoClient;

setTimeout(connectDB,3000);

app.get('/', function(req, res) {
    res.json({"hello": "world"});
});

app.listen(PORT, function(){
    console.log('Your node js server is running on PORT:',PORT);
});

function connectDB() {
    client.connect(url, function(err, db) {
        if(err) {
            console.log('database is not connected')
        }
        else {
            console.log('connected!!')
        }
    })
}
